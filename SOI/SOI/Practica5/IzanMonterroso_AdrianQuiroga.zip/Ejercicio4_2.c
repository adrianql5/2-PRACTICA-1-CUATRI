#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Imagen cambiada\n");

    // Pausar para que puedas inspeccionar la memoria con pmap o gdb
    printf("Presiona una tecla para continuar...\n");
    getchar();

    return 0;
}

